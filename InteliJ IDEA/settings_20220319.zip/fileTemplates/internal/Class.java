#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")

/**
 * @author langyastudio
 * @date ${YEAR}年${MONTH}月${DAY}日 
 */
public class ${NAME} {
}
