/**
 * XXXX功能简述
 * @author 江加雄
 * @version ${YEAR}-${MONTH}-${DAY}
 */